package tp.iut.tp.introspection.data;

public class Thing {
	
	public String name;
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getName() {
		return name;
	}

}
