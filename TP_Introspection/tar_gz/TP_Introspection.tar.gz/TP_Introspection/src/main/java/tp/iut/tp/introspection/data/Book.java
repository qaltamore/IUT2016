package tp.iut.tp.introspection.data;

public class Book {
	
	public String title;
	
	public void setTitle(String newTitle) {
		this.title = newTitle;
	}

}
